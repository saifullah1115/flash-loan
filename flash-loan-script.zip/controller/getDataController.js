import axios from "axios";
import Web3 from "web3";
import asyncHandler from "express-async-handler";

import { kyberRouterAbi } from "../abis/kyberRouterAbi.js";
import { apeRouterAbi } from "../abis/apeRouterAbi.js";
import { quickSwapAbi } from "../abis/quickSwapRouterAbi.js";
import { sushiSwapAbi } from "../abis/sushiSwapRouterAbi.js";

export const getAddresses = asyncHandler(async (req, res) => {
  let pairAddresses = [];
  let baseTokens = [];
  let quoteTokens = [];
  let apeSwapValues = [];
  let quickSwapValues = [];
  let sushiSwapValues = [];
  let minResponseArr = [];
  let maxResponseArr = [];
  let obj = {};
  let min = {};
  let max = {};
  const resultArrays = [];

  const amountOut = 1;
  const USDT = "0xc2132D05D31c914a87C6611C10748AEb04B58e8F";

  const KYBER_ROUTER = "0x546C79662E028B661dFB4767664d0273184E4dD1";
  const APE_ROUTER = "0xC0788A3aD43d79aa53B09c2EaCc313A787d1d607";
  const QUICKSWAP_ROUTER = "0xa5E0829CaCEd8fFDD4De3c43696c57F7D7A678ff";
  const SUSHISWAP_ROUTER = "0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506";

  const web3 = new Web3(
    new Web3.providers.HttpProvider("https://rpc-mainnet.maticvigil.com/")
  );

  let kyberContract = new web3.eth.Contract(kyberRouterAbi, KYBER_ROUTER);
  let apeContract = new web3.eth.Contract(apeRouterAbi, APE_ROUTER);
  let quickSwapContract = new web3.eth.Contract(quickSwapAbi, QUICKSWAP_ROUTER);
  let sushiSwapContract = new web3.eth.Contract(sushiSwapAbi, SUSHISWAP_ROUTER);

  await axios
    .get(`https://api.dexscreener.com/latest/dex/tokens/${USDT}`)
    .then(async (res) => {
      for (let i = 0; i < res.data.pairs.length; i++) {
        pairAddresses.push(res.data.pairs[i].pairAddress);
        baseTokens.push(res.data.pairs[i].baseToken.address);

        quoteTokens.push(res.data.pairs[i].quoteToken.address);
      }
      console.log("Base Token", baseTokens);
      for (let i = 0; i < baseTokens.length; i++) {
        await apeContract.methods
          .getAmountsOut(web3.utils.toWei(String(amountOut), "ether"), [
            baseTokens[i].toString(),
            quoteTokens[i].toString(),
          ])
          .call()
          .then((res) => {
            console.log("APE Swap", res[1] / 1000000, baseTokens[i], res);
            obj = {
              tokenAddress: baseTokens[i],
              price: res[1] / 1000000,
              router: APE_ROUTER,
            };
            apeSwapValues.push(obj);
          })
          .catch((err) => {
            console.log("Ape Swap Error", err.data);
            if (err.data == null) {
              obj = {
                tokenAddress: baseTokens[i],
                price: "0",
              };
              apeSwapValues.push(obj);
            }
          });

        await quickSwapContract.methods
          .getAmountsOut(web3.utils.toWei(String(amountOut), "ether"), [
            baseTokens[i].toString(),
            quoteTokens[i].toString(),
          ])
          .call()
          .then((res) => {
            console.log("Quick Swap", res[1] / 1000000, baseTokens[i], res);
            obj = {
              tokenAddress: baseTokens[i],
              price: res[1] / 1000000,
              router: QUICKSWAP_ROUTER,
            };
            quickSwapValues.push(obj);
          })
          .catch((err) => {
            console.log("Quick Swap Error", err.data);
            if (err.data == null) {
              obj = {
                tokenAddress: baseTokens[i],
                price: "0",
              };
              quickSwapValues.push(obj);
            }
          });

        await sushiSwapContract.methods
          .getAmountsOut(web3.utils.toWei(String(amountOut), "ether"), [
            baseTokens[i].toString(),
            quoteTokens[i].toString(),
          ])
          .call()
          .then((res) => {
            console.log("Susuhi Swap", res[1] / 1000000, baseTokens[i], res);
            obj = {
              tokenAddress: baseTokens[i],
              price: res[1] / 1000000,
              router: SUSHISWAP_ROUTER,
            };
            sushiSwapValues.push(obj);
          })
          .catch((err) => {
            console.log("Sushi swap Error", err.data);
            if (err.data == null) {
              obj = {
                tokenAddress: baseTokens[i],
                price: "0",
              };
              sushiSwapValues.push(obj);
            }
          });
      }

      for (let i = 0; i < baseTokens.length; i++) {
        if (!resultArrays[i]) {
          resultArrays[i] = [];
        }

        resultArrays[i].push(apeSwapValues[i]);
        resultArrays[i].push(quickSwapValues[i]);
        resultArrays[i].push(sushiSwapValues[i]);
      }

      for (let i = 0; i < resultArrays.length; i++) {
        min = JSON.stringify(
          resultArrays[i].reduce(function (prev, current) {
            return prev.price > 0 && prev.price < current.price
              ? prev
              : current;
          })
        );
        max = JSON.stringify(
          resultArrays[i].reduce(function (prev, current) {
            return prev.price > 0 && prev.price > current.price
              ? prev
              : current;
          })
        );
        minResponseArr.push(min, max);
      }
    });
  res.send(minResponseArr);
});
