import express from "express";
import { getAddresses } from "./controller/getDataController.js";


const app = express();
app.listen(5887);


app.use("/getData",getAddresses)


app.use("/",()=>{
  console.log("Server Running")
})
